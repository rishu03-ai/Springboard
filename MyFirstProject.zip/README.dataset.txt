# ComputerVision > 2025-12-04 7:36pm
https://universe.roboflow.com/computervision-lzgvq/computervision-yps9c

Provided by a Roboflow user
License: CC BY 4.0

